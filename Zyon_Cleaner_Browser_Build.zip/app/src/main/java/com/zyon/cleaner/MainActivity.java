// Java / Android / API 23+ / MainActivity.java
package com.zyon.cleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView cacheValue, storageValue, statusValue;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        refreshStats();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(20));
        root.setBackgroundColor(Color.rgb(12, 18, 31));

        TextView brand = text("ZYON CLEANER", 25, Color.WHITE, true);
        root.addView(brand);
        TextView subtitle = text("Limpeza simples. Sem promessas falsas.", 14, Color.rgb(177, 190, 211), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(6);
        root.addView(subtitle, subLp);

        TextView cardTitle = text("ARMAZENAMENTO", 13, Color.rgb(112, 221, 190), true);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackgroundColor(Color.rgb(25, 34, 52));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.topMargin = dp(28);
        root.addView(card, cardLp);
        card.addView(cardTitle);
        storageValue = text("Calculando espaço...", 22, Color.WHITE, true);
        LinearLayout.LayoutParams valLp = new LinearLayout.LayoutParams(-1, -2);
        valLp.topMargin = dp(12);
        card.addView(storageValue, valLp);
        TextView cacheLabel = text("Cache deste limpador", 13, Color.rgb(177, 190, 211), false);
        LinearLayout.LayoutParams cacheLabelLp = new LinearLayout.LayoutParams(-1, -2);
        cacheLabelLp.topMargin = dp(18);
        card.addView(cacheLabel, cacheLabelLp);
        cacheValue = text("Calculando...", 17, Color.WHITE, true);
        card.addView(cacheValue);

        Button clean = button("LIMPAR CACHE DO ZYON");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, dp(54));
        btnLp.topMargin = dp(24);
        root.addView(clean, btnLp);
        clean.setOnClickListener(v -> confirmClean());

        Button system = button("ABRIR CONFIGURAÇÕES DE ARMAZENAMENTO");
        LinearLayout.LayoutParams sysLp = new LinearLayout.LayoutParams(-1, dp(54));
        sysLp.topMargin = dp(12);
        root.addView(system, sysLp);
        system.setOnClickListener(v -> openStorageSettings());

        statusValue = text("O app só apaga arquivos do próprio cache. Fotos, vídeos e documentos ficam intactos.", 13,
                Color.rgb(177, 190, 211), false);
        statusValue.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(22);
        root.addView(statusValue, statusLp);

        TextView footer = text("Sem anúncios • Sem coleta de dados • Sem acesso a fotos", 12,
                Color.rgb(112, 221, 190), false);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(18);
        root.addView(footer, footLp);

        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(12, 18, 31));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(112, 221, 190)));
        return b;
    }

    private void refreshStats() {
        long total = 0, free = 0;
        try {
            StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
            total = fs.getTotalBytes();
            free = fs.getAvailableBytes();
        } catch (Exception ignored) { }
        storageValue.setText(formatBytes(free) + " livres");
        cacheValue.setText(formatBytes(folderSize(getCacheDir())));
    }

    private void confirmClean() {
        long before = folderSize(getCacheDir());
        new AlertDialog.Builder(this)
            .setTitle("Limpar cache?")
            .setMessage("O Zyon vai apagar " + formatBytes(before) +
                    " de arquivos temporários criados por este aplicativo. Seus arquivos pessoais não serão apagados.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar", (dialog, which) -> {
                long deleted = clearDirectory(getCacheDir());
                refreshStats();
                statusValue.setText("Limpeza concluída. Espaço temporário liberado: " + formatBytes(deleted) + ".");
                Toast.makeText(this, "Cache limpo: " + formatBytes(deleted), Toast.LENGTH_LONG).show();
            }).show();
    }

    private void openStorageSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Abra Configurações > Armazenamento.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private long folderSize(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += folderSize(child);
        return total;
    }

    private long clearDirectory(File dir) {
        long deleted = 0;
        File[] children = dir.listFiles();
        if (children == null) return 0;
        for (File child : children) {
            long size = folderSize(child);
            if (child.isDirectory()) {
                clearDirectory(child);
                File[] remaining = child.listFiles();
                if (remaining != null && remaining.length == 0) child.delete();
            } else if (child.delete()) {
                deleted += size;
            }
        }
        return deleted;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.getDefault(), "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.getDefault(), "%.1f MB", mb);
        return String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0);
    }
}
