# Zyon Cleaner

Aplicativo Android nativo, sem anúncios e sem permissões de armazenamento.

## Funções
- Exibe espaço disponível no armazenamento.
- Calcula o tamanho do cache privado do próprio Zyon Cleaner.
- Limpa apenas esse cache, após confirmação.
- Abre as configurações de armazenamento do Android para a limpeza geral do sistema.

## Limites do Android
Um aplicativo comum não pode limpar o cache privado de outros apps. O Android também não concede acesso amplo a arquivos pessoais sem seleção/permissão explícita. Por isso, este projeto não promete apagar lixo de outros aplicativos nem usa acessibilidade, root ou comandos ocultos.

## Compilar
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Instale Android SDK Platform 35 e JDK 17.
4. Selecione `app > assembleDebug` na janela Gradle, ou execute `./gradlew assembleDebug` após adicionar o wrapper executável/distribuição.
5. APK de depuração: `app/build/outputs/apk/debug/app-debug.apk`.

O arquivo `gradle/wrapper/gradle-wrapper.properties` foi incluído com a configuração Gradle 8.7 fornecida.

## Build APK pelo navegador (GitHub Actions)
1. Extraia este ZIP no celular.
2. No navegador, crie um repositório no GitHub.
3. Envie todos os arquivos e pastas extraídos, incluindo a pasta `.github` (arquivos ocultos podem não aparecer em alguns gerenciadores).
4. Abra a aba **Actions** do repositório e execute **Build Zyon Cleaner APK** (Run workflow). Se o fluxo não aparecer, confirme que `.github/workflows/build-apk.yml` foi enviado.
5. Quando terminar com sucesso, abra a execução e baixe o artefato **Zyon-Cleaner-debug-APK**. Dentro do ZIP do artefato estará `app-debug.apk`.

O APK gerado é uma versão de depuração, não assinada para publicação na Play Store. Revise o código antes de instalar.
